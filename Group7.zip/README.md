HINDI SENTIMENT ANALYSIS
========================

Analysis of hindi text for classification into positive, negative and neutral.

Usage: python algo.py <filename.xlsx>

Output would be in OUTPUT.txt in the format:
	sno,polarity

Polarity:
- Positive : 1
- Negative : -1
- Neutral : 0

AUTHORS
=======
* Lohitaksh Parmar 
* Palash Bansal
* Shivam Rustogi